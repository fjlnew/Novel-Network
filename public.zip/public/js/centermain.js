function getbookkinds() {
    $.ajax({
        url: '/getbookkinds',
        type: 'post',
        success: function (data) {
            bookkinds = data.bookkinds;
            bookkindsdraw(bookkinds);
        }
    })
}
//分页实现
// function getweekbooks(i) {
//     var weekbooksgo = parseInt(i) * 2;
//     var data = $.param({
//         "weekbooksgo": weekbooksgo
//     }) + "&" + $("#editform").serialize() + "";
//     console.log(data);
//     $.ajax({
//         url: `/getweekbooks`,
//         type: 'post',
//         data: data,
//         success: function (data) {
//             weekbooks = data.weekbooks;
//             var booklist = document.querySelectorAll('.booklist');
//             booksdraw(booklist[0], weekbooks);
//         }
//     })
// }
// var i = 1;
// getweekbooks(i);
// function xiayiye() {
//     i = i + 1;
//     getweekbooks(i);
// }

function getweekbooks() {
    $.ajax({
        url: '/getweekbooks',
        type: 'post',
        success: function (data) {
            weekbooks = data.weekbooks;
            var booklist = document.querySelectorAll('.booklist');
            booksdraw(booklist[0], weekbooks);
        }
    })
}

function getnewbooks() {
    $.ajax({
        url: '/getnewbooks',
        type: 'post',
        success: function (data) {
            newbooks = data.newbooks;
            var booklist = document.querySelectorAll('.booklist');
            booksdraw(booklist[1], newbooks);
        }
    })
}

function lunbobox() {
    $.ajax({
        url: '/lunbobox',
        type: 'post',
        success: function (data) {
            lunbobox = data.lunbobox;
            lunboboxdraw(lunbobox);
        }
    })
}

function tuijianbook() {
    $.ajax({
        url: '/tuijianbook',
        type: 'post',
        success: function (data) {
            tuijianbook = data.tuijianbook;
            eidrecdraw(tuijianbook);
        }
    })
}
getnewbooks();
getbookkinds();
getweekbooks();
lunbobox();
tuijianbook();

function eidrecdraw(tuijianbook) {
    var id = 0;
    var eidul = document.querySelectorAll('.eit-rec-list');
    for (var i = 0; i < 3; i++) {
        var eidulli = document.createElement('li');
        if (i >= 1) {
            eidulli.className = 'ml30';
        }
        eidulli.innerHTML = ` 
        <h3><a href="/bookviews?bookid=${tuijianbook[id].bookid}">${tuijianbook[id].bookname}</a></h3>
        <em class="total"><cite>${tuijianbook[id].bookReaders}</cite><i>人在追</i></em>
        <div class="jj">${tuijianbook[id].bookintroduce}</div>`;
        id++;
        eidul[0].appendChild(eidulli);
        var eidulli2 = document.createElement('li');
        if (i >= 1) {
            eidulli2.className = 'ml30';
        }
        eidulli2.innerHTML = ` 
        <h3><a href="/bookviews?bookid=${tuijianbook[id].bookid}">${tuijianbook[id].bookname}</a></h3>
        <em class="total"><cite>${tuijianbook[id].bookReaders}</cite><i>人在追</i></em>
        <div class="jj">${tuijianbook[id].bookintroduce}</div>`;
        id++;
        eidul[1].appendChild(eidulli2);
    }
}

function bookkindsdraw(bookkinds) {
    var cite = document.querySelectorAll('.cite');
    for (var i = 0; i < cite.length; i++) {
        let info = document.createElement('span');
        info.className = 'info';
        cite[i].appendChild(info);
        let myi = document.createElement('i');
        myi.innerHTML = bookkinds[i].kindname;
        info.appendChild(myi);
        let myb = document.createElement('b');
        myb.innerHTML = bookkinds[i].kindnum;
        info.appendChild(myb);
    }
}

function booksdraw(element, booklist) {
    var booklistul = document.createElement('ul');
    element.appendChild(booklistul);
    for (var i = 0; i < 18; i++) {
        var booklistli = document.createElement('li');
        booklistul.appendChild(booklistli);
        var channel = document.createElement('a');
        channel.className = 'channel';
        channel.href = '#';
        channel.innerHTML = `<i>&nbsp;[</i>${booklist[i].kindname}<i>]</i>`
        booklistli.appendChild(channel);
        var bookname = document.createElement('a');
        bookname.className = 'bookname';
        bookname.href = `/bookviews?bookid=${booklist[i].bookid}`;
        bookname.innerHTML = `${booklist[i].bookname}`
        booklistli.appendChild(bookname);
        if (booklist[i].bookReaders > 65000) {
            var hot = document.createElement('div');
            hot.className = 'hot';
            bookname.appendChild(hot);
        }
        var author = document.createElement('a');
        author.className = 'author';
        author.href = '#';
        author.innerHTML = `${booklist[i].bookautor}`
        booklistli.appendChild(author);
    }
}

function lunboboxdraw(lunbobox) {
    var i = 0;
    var sliders = document.querySelectorAll('.sliders div');
    var descwrap = document.querySelectorAll('.description .desc-wrap');
    sliders.forEach(elme => {
        var lunboimg = document.createElement('img');
        lunboimg.src = `../public/img/smalllunbo/${lunbobox[i].bookname}.jpg`;
        elme.appendChild(lunboimg);
        var smalldivh3 = document.createElement('h3');
        smalldivh3.innerHTML = `${lunbobox[i].bookname}`;
        descwrap[i].appendChild(smalldivh3);
        var smalldivp = document.createElement('p');
        smalldivp.innerHTML = `${lunbobox[i].bookintroduce}`;
        descwrap[i].appendChild(smalldivp);
        var smalldiva = document.createElement('a');
        smalldiva.href = `/bookviews?bookid=${lunbobox[i].bookid}`;
        smalldiva.innerHTML = `书籍详情`;
        descwrap[i].appendChild(smalldiva);
        i++;
    });

}
var mydiv = document.querySelector('.publicityspan');
var length = parseInt(getComputedStyle(mydiv).width);
var size = 0;

function stop() {
    clearInterval(t);
}

function start() {
    t = setInterval('huandong(size)', 100);
}

function huandong(mysize) {
    mydiv.style.marginLeft = '-' + mysize + 'px';
    size = (mysize + 5) % (length + 170);
}
var t = setInterval('huandong(size)', 100);


var nowplace = 0;

function lunbosliders(place) {
    var sliders = document.querySelectorAll('.sliders div');
    var descriptiondiv = document.querySelectorAll('.description .desc-wrap');
    sliders[place].style.transform = 'scale(1)';
    sliders[place].style.right = '0px';
    sliders[place].style.zIndex = '8';
    descriptiondiv[place].style.display = 'block';
    descriptiondiv[(place + 1) % 5].style.display = 'none';
    descriptiondiv[(place + 2) % 5].style.display = 'none';
    descriptiondiv[(place + 3) % 5].style.display = 'none';
    descriptiondiv[(place + 4) % 5].style.display = 'none';
    sliders[(place + 1) % 5].style.transform = 'scale(.8)';
    sliders[(place + 1) % 5].style.right = '-44.64px';
    sliders[(place + 1) % 5].style.zIndex = '7';
    sliders[(place + 4) % 5].style.transform = 'scale(.8)';
    sliders[(place + 4) % 5].style.right = '44.64px';
    sliders[(place + 4) % 5].style.zIndex = '7';
    sliders[(place + 2) % 5].style.transform = 'scale(.6)';
    sliders[(place + 2) % 5].style.right = '-80.64px';
    sliders[(place + 2) % 5].style.zIndex = '6';
    sliders[(place + 3) % 5].style.transform = 'scale(.6)';
    sliders[(place + 3) % 5].style.right = '80.64px';
    sliders[(place + 3) % 5].style.zIndex = '6';
    sliders.forEach(el => {
        el.onclick = function () {
            nowplace = el.dataset.rid - 1;
            lunbosliders(el.dataset.rid - 1)
        }
    });
}
lunbosliders(nowplace);

function lunboone(i) {
    if (i == 1) {
        nowplace = (nowplace + 1) % 5;
        lunbosliders(nowplace);
    } else {
        nowplace = (nowplace + 4) % 5;
        lunbosliders(nowplace);
    }
}

function lunboto(s) {
    nowplace = s - 1;
    lunbosliders(nowplace);
}

var sitenav = document.querySelectorAll('.site-nav ul li');
sitenav.forEach(el => {
    el.onmouseover = function () {
        el.classList.add('act')
    }
    el.onmouseout = function () {
        el.classList.remove('act')
    }
});

var topselect = document.querySelector('.pin-nav');
document.onscroll = function () {
    if (document.documentElement.scrollTop > 300) {
        topselect.classList.add('show')
    } else {
        topselect.classList.remove('show')
    }
}



function logintap() {
    var mask = document.querySelector('.mask');
    var qdloginwrap = document.querySelector('.qdlogin-wrap');
    mask.classList.remove('disnone');
    qdloginwrap.classList.remove('disnone');
}

function closelogin() {
    var mask = document.querySelector('.mask');
    var qdloginwrap = document.querySelector('.qdlogin-wrap');
    mask.classList.add('disnone');
    qdloginwrap.classList.add('disnone');
}

function gologin() {
    var loginmodedd = document.querySelectorAll('.login-mode dl dd');
    var errtip = document.querySelector('.err-tip');
    var username = document.querySelector('#username').value;
    var passworld = document.querySelector('#passworld').value;
    var isok1 = true;
    var isok2 = true;
    if (username == '') {
        loginmodedd[0].style.border = '1px solid red';
        isok1 = false;
    } else {
        loginmodedd[0].style.border = '1px solid #E6E6E6';
        isok1 = true;
    }
    if (passworld == '') {
        loginmodedd[1].style.border = '1px solid red';
        isok2 = false;
    } else {
        loginmodedd[1].style.border = '1px solid #E6E6E6';
        isok2 = true;
    }
    if (isok1 && isok2) {
        var data = $.param({
            "username": username
        }) + "&" + $.param({
            "passworld": passworld
        }) + "&" + $("#editform").serialize() + "";
        $.ajax({
            url: `/gotologin`,
            type: 'post',
            data: data,
            success: function (data) {
                if (data.haveit.haveit) {
                    location.reload();
                } else {
                    loginmodedd[0].style.border = '1px solid red';
                    loginmodedd[1].style.border = '1px solid red';
                    errtip.classList.remove('disnone');
                    isok2 = false;
                    isok2 = false;
                }
            }
        })
    }
}

